import pandas as pd
import matplotlib.pyplot as plt
import sys


#reading data frame from a csv file
df=pd.read_csv(sys.argv[1], header=None, names=['col1','col2'])

#plot bar plot with xticks which is position of bars as first argument and height of bars as second argument
plt.bar([1,2,3,4,5,6,7,8],df['col2'],color='#ddbbaa',label="bar-label")

#specify labels on xticks
plt.xticks([1,2,3,4,5,6,7,8],["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana"])
plt.xlabel("States")
plt.ylabel("Sex Ratio")

#enabling legend
plt.legend()
plt.show()

